RIM_SERVICE_URL = "https://rim.attestation.nvidia.com/v1/rim/"
ALLOW_HOLD_CERT = True
OCSP_SERVICE_URL = "https://ocsp.ndis.nvidia.com/"
REMOTE_VERIFIER_URL = "https://nras.attestation.nvidia.com/v1/attest/gpu"
# Planned to move the below to a list of acceptable GPU architectures
GPU_ARCH = "HOPPER"
